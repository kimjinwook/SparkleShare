package com.example.timetable;

import java.io.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Bundle;
import android.telephony.*;
import android.text.Spannable;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.*;
import android.view.ContextMenu.*;
import android.view.View.OnClickListener;
import android.widget.*;

public class MainActivity extends Activity implements OnClickListener {

	private Button make_timetable, road_timetable, delete_timetable, help, exit;	//	메인의 4개 버튼
	//private TextView main_text;														//	제목
	private Typeface /*main_text_font, */button_font;									//	폰트
	private Intent intent;															//	보내는 인텐트
	private AlertDialog.Builder message_box;										//	다이얼로그
	private AlertDialog ad;															//	다이얼로그를 사용하기 위해
	private Database db = null;														//	Database 클레스 선언
	private SQLiteDatabase sql_db;													//	db정보
	private Cursor cursor;															//	select 쿼리문 사용을 위해 선언
	private int num = 1;															//	ContextMenu에 사용될 변수
	private Drawable make_btn_alpha, road_btn_alpha, delete_btn_alpha, help_btn_alpha, exit_btn_alpha;	//	투명도
	private static int road_or_clear = 0;											//	불러오기, 삭제하기 버튼 구별

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);	// 화면을 전체화면으로 변경

		try {
			db_create();						//	assets/database폴더에 있는 db파일을 현재 AVD에 설치
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();				//	에러시 프린트
		}

		init();									//	변수 초기화
		setFont();								//	폰트 지정
		message_box();							//	다이얼로그 초기화
		makealpha();							//	투명도 조정

		//	이벤트 지정
		make_timetable.setOnClickListener(this);
		registerForContextMenu(road_timetable);
		registerForContextMenu(delete_timetable);
		help.setOnClickListener(this);
		exit.setOnClickListener(this);
	}

	//	assets/database폴더에 있는 db파일을 현재 AVD에 설치
		
	private void createFolder(String folderpath)
	{
	   File file = new File(folderpath);
	   if(!file.exists()) file.mkdirs();
	}
	
	private void db_create() throws IOException{
		createFolder("/mnt/sdcard/Data/databases/");
		File outfile = new File("/mnt/sdcard/Data/databases/table.db");
		AssetManager am = getResources().getAssets();
		InputStream is = am.open("database/table.db", AssetManager.ACCESS_BUFFER);
		long filesize = is.available();

		if(outfile.length() < filesize){
			byte[] data = new byte[(int)filesize];
			is.read(data);
			is.close();
			outfile.createNewFile();
			FileOutputStream fos = new FileOutputStream(outfile);
			fos.write(data);
			fos.close();
		}
	}

	//	변수 초기화
	private void init() {
		// TODO Auto-generated method stub
		db = new Database(this);
		message_box = new AlertDialog.Builder(this);

		make_timetable = (Button)findViewById(R.id.make_timetable);
		road_timetable = (Button)findViewById(R.id.road_timetable);
		delete_timetable = (Button)findViewById(R.id.delete_timetable);
		help = (Button)findViewById(R.id.help);
		exit = (Button)findViewById(R.id.exit);

		make_btn_alpha = make_timetable.getBackground();
		road_btn_alpha = road_timetable.getBackground();
		delete_btn_alpha = delete_timetable.getBackground();
		help_btn_alpha = help.getBackground();
		exit_btn_alpha = exit.getBackground();

		//main_text = (TextView)findViewById(R.id.main_text);

		//main_text_font = Typeface.createFromAsset(getAssets(), "MILKYWAY.TTF");
		button_font = Typeface.createFromAsset(getAssets(), "menufont.ttf");
	}

	//	폰트 지정
	private void setFont(){
		//main_text.setTypeface(main_text_font);
		make_timetable.setTypeface(button_font);
		road_timetable.setTypeface(button_font);
		delete_timetable.setTypeface(button_font);
		help.setTypeface(button_font);
		exit.setTypeface(button_font);
	}

	//	Context 메뉴 초기화
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
		super.onCreateContextMenu(menu, v, menuInfo);
		db = new Database(this);
		if(v == road_timetable){
			menu.setHeaderTitle("무엇을 불러올까요?");
			sql_db = db.getReadableDatabase();   //읽기전용으로 데이터베이스를 오픈
			cursor = sql_db.rawQuery("select name from SaveTable", null);
			if(cursor.moveToNext()){
				cursor.close();
				String name = "";
				cursor = sql_db.rawQuery("select name from SaveTable", null);
				while(cursor.moveToNext()){
					if(name.equals(cursor.getString(0)))
						continue;
					else{
						name = cursor.getString(0);
						menu.add(num, 0, 0, name);
						num++;
					}
				}
				num = 0;
				cursor.close();
				db.close();
			}
			road_or_clear = 0;
		}
		else{
			menu.setHeaderTitle("무엇을 지울까요?");

			sql_db = db.getReadableDatabase();
			cursor = sql_db.rawQuery("select name from SaveTable", null);

			if(cursor.moveToNext()){
				cursor.close();
				String name = "";
				cursor = sql_db.rawQuery("select name from SaveTable", null);
				while(cursor.moveToNext()){
					if(name.equals(cursor.getString(0)))
						continue;
					else{
						name = cursor.getString(0);
						menu.add(0, num, 0, name);
						num++;
					}
				}
				num = 0;
				cursor.close();
				db.close();
			}
			road_or_clear = 1;
		}
	}

	//	Context 메뉴 중 선택시 실행될 상태 선언
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if(road_or_clear == 0){		// 불러오기인 경우
			finish();
			intent = new Intent(MainActivity.this, TimeTable.class);
			intent.putExtra("table_name", item.getTitle());
			startActivity(intent);
			return true;
		}
		else{	// 지우기인 경우
			sql_db = db.getWritableDatabase();
			sql_db.execSQL("delete from SaveTable where name='"+item.getTitle()+"';");
			db.close();
			ad.show();
		}
		return true;
	}

	//	다이얼로그 초기화
	private void message_box() {
		// TODO Auto-generated method stub
		message_box.setIcon(R.drawable.android_logo);
		message_box.setTitle("삭제완료!!");
		message_box.setPositiveButton("확인", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
			}
		});
		ad = message_box.create();
	}

	//	투명도 조정
	private void makealpha(){
		// TODO Auto-generated method stub
		make_btn_alpha.setAlpha(200);
		road_btn_alpha.setAlpha(200);
		delete_btn_alpha.setAlpha(200);
		help_btn_alpha.setAlpha(200);
		exit_btn_alpha.setAlpha(200);
	}
	
	//	이벤트 지정
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v == make_timetable){
			intent = new Intent(MainActivity.this, TimeTableSetting.class);
			startActivity(intent);
		}
		else if(v == help){
			intent = new Intent(MainActivity.this, Help.class);
			startActivity(intent);
		}
		else{
			finish();
		}
	}
}