package com.example.timetable;

public class Filter {
	//	받은 교시를 int 값으로 넘겨주는 부분 (실패시 -1)
	public int Filter_time(String time){
		if(time.equals("1교시"))
			return 0;
		else if(time.equals("2교시"))
			return 1;
		else if(time.equals("3교시"))
			return 2;
		else if(time.equals("4교시"))
			return 3;
		else if(time.equals("5교시"))
			return 4;
		else if(time.equals("6교시"))
			return 5;
		else if(time.equals("7교시"))
			return 6;
		else if(time.equals("8교시"))
			return 7;
		else if(time.equals("9교시"))
			return 8;
		else
			return -1;
	}
	//	받은 요일은 int값으로 넘겨주는 부분
	public int Filter_day(String day){
		if(day.equals("월요일"))
			return 0;
		else if(day.equals("화요일"))
			return 1;
		else if(day.equals("수요일"))
			return 2;
		else if(day.equals("목요일"))
			return 3;
		else if(day.equals("금요일"))
			return 4;
		else if(day.equals("토요일"))
			return 5;
		else if(day.equals("일요일"))
			return 6;
		else
			return -1;
	}
}
