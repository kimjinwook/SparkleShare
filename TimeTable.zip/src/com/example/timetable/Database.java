package com.example.timetable;

import java.io.*;

import android.content.*;
import android.database.sqlite.*;
import android.util.*;

//	데이터베이스 파일 생성을 위해 지정
public class Database extends SQLiteOpenHelper{  
	//	최초 선언시 불려오는 곳. db파일을 생성하거나 불러옴
	public Database(Context context) {
		super(context, "table.db", null, 1);
		// TODO Auto-generated constructor stub
	}

	//	테이블이 없을 경우 생성
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE TimeTable (time_ varchar(50), time varchar(50), day varchar(10), contents varchar(100));");
		db.execSQL("CREATE TABLE SaveTable (num int(10), name varchar(50), time_ varchar(50), time varchar(50), day varchar(10), contents varchar(100));");
	}

	//	테이블을 삭제해야할시 삭제
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}
}