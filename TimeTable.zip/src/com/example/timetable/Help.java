package com.example.timetable;

import android.app.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.View.OnClickListener;
import android.widget.*;

public class Help extends Activity implements OnClickListener{
	
	TextView help_text_1, help_text_2, help_text_3, help_text_4, help_text_5, help_text_6, help_text_7;	//	안내문
	Button back;							//	뒤로가기 버튼
	Typeface text_font, button_font;		//	폰트
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);	// 화면을 전체화면으로 변경

		init();			//	변수 초기화
		setFont();		//	폰트 설정
		//	이벤트 선언
		back.setOnClickListener(this);
	}

	//	변수 초기화
	private void init() {
		// TODO Auto-generated method stub
		help_text_1 = (TextView)findViewById(R.id.t1);
		help_text_2 = (TextView)findViewById(R.id.t2);
		help_text_3 = (TextView)findViewById(R.id.t3);
		help_text_4 = (TextView)findViewById(R.id.t4);
		help_text_5 = (TextView)findViewById(R.id.t5);
		help_text_6 = (TextView)findViewById(R.id.t6);
		help_text_7 = (TextView)findViewById(R.id.t7);
		
		back = (Button)findViewById(R.id.back);
		
		text_font = Typeface.createFromAsset(getAssets(), "piano.ttf");
		button_font = Typeface.createFromAsset(getAssets(), "menufont.ttf");
	}
	//	폰트 설정
	private void setFont(){
		help_text_1.setTypeface(text_font);
		help_text_2.setTypeface(text_font);
		help_text_3.setTypeface(text_font);
		help_text_4.setTypeface(text_font);
		help_text_5.setTypeface(text_font);
		help_text_6.setTypeface(text_font);
		help_text_7.setTypeface(text_font);
		back.setTypeface(button_font);
	}
	//	이벤트 설정
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		finish();
	}
}
